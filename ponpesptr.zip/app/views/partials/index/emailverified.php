<div class="container">
	<h4>Email verification completed.</h4>
	<hr />
	<div class="">
		<a href="<?php print_link('index') ?>" class="btn btn-primary">Continue</a>
	</div>
</div>



