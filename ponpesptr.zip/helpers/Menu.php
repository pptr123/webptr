<?php
/**
 * Menu Items
 * All Project Menu
 * @category  Menu List
 */

class Menu{
	
	
			public static $navbarsideleft = array(
		array(
			'path' => 'home', 
			'label' => 'Home', 
			'icon' => '<i class="fa fa-home "></i>'
		),
		
		array(
			'path' => 'data_hafalan', 
			'label' => 'Data Hafalan', 
			'icon' => '<i class="fa fa-book "></i>'
		),
		
		array(
			'path' => 'data_santri', 
			'label' => 'Data Santri', 
			'icon' => '<i class="fa fa-user "></i>'
		),
		
		array(
			'path' => 'user', 
			'label' => 'User', 
			'icon' => '<i class="fa fa-user-secret "></i>'
		),
		
		array(
			'path' => 'role_permissions', 
			'label' => 'Role Permissions', 
			'icon' => ''
		),
		
		array(
			'path' => 'roles', 
			'label' => 'Roles', 
			'icon' => ''
		)
	);
		
	
	
			public static $jk = array(
		array(
			"value" => "Laki - Laki", 
			"label" => "Laki - Laki", 
		),
		array(
			"value" => "Perempuan", 
			"label" => "Perempuan", 
		),);
		
			public static $jk2 = array(
		array(
			"value" => "Laki - Laki", 
			"label" => "Laki - Laki", 
		),
		array(
			"value" => "Perempuan ", 
			"label" => "Perempuan", 
		),);
		
}